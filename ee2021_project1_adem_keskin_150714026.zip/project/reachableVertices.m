function graphtheory=reachableVertices(A)
%reachableVertices gives the set of reacheable vertices for each vertex
%adjacency matrix is a square matrix which represents the connections of the vertices in the graph
%This function gets reachable vertices according to an adjacency matrix 

if size(A,1)~=size(A,2)%checking if it is not adjacency matrix
error('please type adjacency matrix!')
end
for ii=1:size(A,1)%checking if undesireble indexs exist
   for jj=1:size(A,2)
     if(A(ii,jj)==0 & A(ii,jj)==1)
error('matrix must contain only 0 s and 1s!')
     end
end
end
reachableSet={};
for jj=1:size(A,2)%checking for each column
kjj=find(A(:,jj)>0);%finding nonzero indexs for columns
k=0;
n=numel(kjj);
 while k<n %it is repeating ,acording to number of nonzero indexs
     k=k+1;
     ljj=find(A(:,kjj(k))>0);%finding next indexs that related columns(greater than 0 for each column)
     mjj=setdiff(ljj,kjj);%not to owerwrite same numbers
     kjj=[kjj;mjj];%adding to finding new indexs
     n=numel(kjj); %because size of kjj is not stable
 end 
 kjj=unique(kjj');%it aline to indexs and convert it left to right
 reachableSet{jj}=kjj;
fprintf('reachableSet{%d}=[ %s ]\n',jj,num2str(kjj));%printing the results in every for step(line 13)
end
end